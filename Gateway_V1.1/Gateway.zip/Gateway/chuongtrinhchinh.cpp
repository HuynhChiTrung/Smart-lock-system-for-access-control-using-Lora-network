// #include "00_LORA.h"
// #include "chuongtrinhchinh.h"

// LORA lora;

// void khoitao() {
//   Serial.begin(9600);
//   lora.khoitao();
//   pinMode(13, OUTPUT);
//   digitalWrite(13, 1);
// }

// void chuongtrinhchinh() {
//   String receivedData = lora.nhandulieu();
//   if (receivedData!= "") {
//     Serial.println();
//     //delay(150);
//    // lora.guidulieu();
//     digitalWrite(13, 0);
//     delay(200);
//     digitalWrite(13, 1);
//   }
//   // else {
//   //   if(receivedData.length() > 0){
//   //     Serial.println();
//   //     Serial.println("Invalid card");
//   //   }
//   //}
// }
#include "00_LORA.h"           // Thư viện cho LoRa
#include "chuongtrinhchinh.h"  // Chương trình chính

LORA lora;  // Khai báo đối tượng LoRa

void khoitao() {
  Serial.begin(115200);  // Tốc độ truyền thông Serial
  lora.khoitao();        // Khởi tạo LORA
  pinMode(13, OUTPUT);   // Cấu hình chân 13 là OUTPUT
  digitalWrite(13, 1);   // Đặt chân 13 ở mức HIGH (đèn tắt)
}

void hienThiMenu() {
  Serial.println("Chọn một tùy chọn:");
  Serial.println("1. Nhập dữ liệu mới");
  Serial.println("2. Gửi dữ liệu đã nhập");
  Serial.println("3. Thoát");
}

void chuongtrinhchinh() {
  int choice = -1;
  char exitChar = ' ';  // Biến lưu ký tự thoát111
  
  String data = "";
  while (true) {  // Vòng lặp chính
    Serial.println("1: Enroll fingerprint");
    Serial.println("2: Delete fingerprint");
    Serial.println("3: Search for fingerprint");
    Serial.println("Nhap 'X' de quay lai menu.");

    // Đảm bảo rằng sẽ không đọc dữ liệu cũ
    while (Serial.available()) {
      Serial.read();  // Xóa sạch buffer của Serial
    }

    // Chờ người dùng nhập lựa chọn hợp lệ (1, 2, 3)
    while (choice < 1 || choice > 3) {
      if (Serial.available() > 0) {
        choice = Serial.parseInt();
        while (Serial.available() > 0) {
          Serial.read();  // Xóa bất kỳ ký tự nào còn sót lại trong buffer sau khi nhập lựa chọn
        }
        if (choice < 1 || choice > 3) {
          Serial.println("Lua chon khong hop le, vui long nhap lai.");
        }
      }
    }

    int id = -1, del_id = -1;

    switch (choice) {
      case 1:  // Enroll nhiều ID cho đến khi nhập 'X'
        exitChar = ' ';
        data = "";
        while (exitChar != 'X') {  // Vòng lặp để nhập nhiều ID cho đến khi người dùng nhấn 'X'
          Serial.println("Nhap ID de them hoac nhap 'X' de quay lai menu:");

          // Chờ cho đến khi có dữ liệu mới từ Serial
          while (Serial.available() == 0) {
            // Vòng lặp đợi người dùng nhập dữ liệu
          }

          if (Serial.peek() == 'X') {  // Kiểm tra nếu người dùng nhập 'X' để thoát
            exitChar = Serial.read();  // Đọc ký tự 'X' để xóa khỏi buffer
            Serial.println("Da quay lai menu.");
            break;  // Thoát ra khỏi case 1 và quay lại menu chính
          } else {
            data = Serial.parseInt();  // Nhận ID nhập vào
            while (Serial.available() > 0) {
              Serial.read();  // Xóa dữ liệu thừa
              lora.guidulieu(data);

              Serial.print("Dang them ID: ");
              Serial.println(data);
              // Gọi hàm enroll
            }
          }
          break;

          case 2:  // Delete nhiều ID cho đến khi nhập 'X'
            exitChar = ' ';
            while (exitChar != 'X') {  // Vòng lặp để xóa nhiều ID cho đến khi người dùng nhấn 'X'
              Serial.println("Nhap ID de xoa hoac nhap 'X' de quay lai menu:");

              // Chờ cho đến khi có dữ liệu mới từ Serial
              while (Serial.available() == 0) {
                // Vòng lặp đợi người dùng nhập dữ liệu
              }

              if (Serial.peek() == 'X') {  // Kiểm tra nếu người dùng nhập 'X' để thoát
                exitChar = Serial.read();  // Đọc ký tự 'X' để xóa khỏi buffer
                Serial.println("Da quay lai menu.");
                break;  // Thoát ra khỏi case 2 và quay lại menu chính
              } else {
                del_id = Serial.parseInt();  // Nhận ID nhập vào
                while (Serial.available() > 0) {
                  Serial.read();  // Xóa dữ liệu thừa
                }
                if (del_id >= 0) {
                  Serial.print("Dang xoa ID: ");
                  Serial.println(del_id);
                  // myFingerPrint.deleteFingerprint(del_id);  // Gọi hàm xóa vân tay
                } else {
                  Serial.println("ID khong hop le, vui long nhap lai.");
                }
              }
            }
            break;

          case 3:
            Serial.println("Dang tim kiem vân tay...");
            // myFingerPrint.getFingerprintID();  // Gọi hàm tìm kiếm vân tay
            if (Serial.peek() == 'X') {  // Kiểm tra nếu người dùng nhập 'X' để thoát
              exitChar = Serial.read();  // Đọc ký tự 'X' để xóa khỏi buffer
              Serial.println("Da quay lai menu.");
              break;
            }

            // Reset lại lựa chọn sau mỗi lần xử lý xong case
        }
        choice = -1;
    }
  }
}