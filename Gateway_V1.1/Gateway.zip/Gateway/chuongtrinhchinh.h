#ifndef _chuongtrinhchinh_h
#define _chuongtrinhchinh_h

void khoitao(void);
void chuongtrinhchinh(void);
#endif